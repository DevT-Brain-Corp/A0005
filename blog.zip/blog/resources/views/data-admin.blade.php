@extends('admin')

@section('content')


<div class="card-header">
  <h5 class="title">Data Admin</h5>
  <p class="category">Seluruh Admin di SOSMEKES</p>
</div>
@endsection
