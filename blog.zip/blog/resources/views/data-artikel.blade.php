@extends('admin')

@section('content')


<div class="card-header">
  <h5 class="title">Data Artikel</h5>
  <p class="category">Seluruh Artikel yang Diunggah pada SOSMEKES</p>
</div>
@endsection
