@extends('admin')

@section('content')


<div class="card-header">
  <h5 class="title">Data Dokter</h5>
  <p class="category">Seluruh Dokter yang menjadi Kontributor pada SOSMEKES</p>
</div>
@endsection
