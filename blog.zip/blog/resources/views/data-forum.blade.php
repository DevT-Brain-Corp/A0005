@extends('admin')

@section('content')


<div class="card-header">
  <h5 class="title">Data Forum Diskusi</h5>
  <p class="category">Seluruh Diskusi yang Diunggah Pengguna pada SOSMEKES</p>
</div>
@endsection
