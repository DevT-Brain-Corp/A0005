@extends('header')

@section('content')
<body>
<div class="page-header clear-filter" filter-color="orange">
  <div class="page-header-image" style="background-image:url(./assets/img/bgdr.jpg)"></div>
  <div class="container">
    <div class="content-center brand">

      <h1 class="h1-seo">Profil Dokter</h1>

    </div>

  </div>

</div>


</body>
@endsection
